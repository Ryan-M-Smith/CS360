/* front.c - a lexical analyzer system for simple arithmetic expressions */
#include <stdio.h>
#include <ctype.h>

#include "globals.h"
#include "factor.h"
#include "term.h"
#include "expr.h"

/* Function declarations */
void addChar();
void getChar();
void getNonBlank();
int  lex();

/******************************************************/
/* main driver */
int main() {
	/* Open the input data file and process its contents */
	if ((in_fp = fopen("front.in", "r")) == NULL)
		printf("ERROR - cannot open front.in \n");
	else {
		getChar();
		lex();
		expr();
	}
}
/*****************************************************/

/* lookup - a function to lookup operators and parentheses
and return the token */
int lookup(char ch) {
	prevToken = nextToken;
	switch (ch) {
		case '(':
			addChar();
			nextToken = LEFT_PAREN;
			break;
		case ')':
			addChar();
			nextToken = RIGHT_PAREN;
			break;
		case '+':
			addChar();
			nextToken = ADD_OP;
			break;
		case '-':
			addChar();
			nextToken = SUB_OP;
			break;
		case '*':
			addChar();
			nextToken = MULT_OP;
			break;
		case '/':
			addChar();
			nextToken = DIV_OP;
			break;
		default:
			addChar();
			nextToken = EOF;
			break;
	}

	return nextToken;
}

/*****************************************************/
/* addChar - a function to add nextChar to lexeme */
void addChar() {
	if (lexLen <= 98) {
		lexeme[lexLen++] = nextChar;
		lexeme[lexLen] = 0;
	}
	else
		printf("Error - lexeme is too long \n");
}

/*****************************************************/

/* getChar - a function to get the next character of
input and determine its character class */
void getChar() {
	if ((nextChar = getc(in_fp)) != EOF) {
		if (isalpha(nextChar))
			charClass = LETTER;
		else if (isdigit(nextChar))
			charClass = DIGIT;
		else charClass = UNKNOWN;
	}
	else
		charClass = EOF;
}

/*****************************************************/
/* getNonBlank - a function to call getChar until it
returns a non-whitespace character */
void getNonBlank() {
	while (isspace(nextChar))
		getChar();
}

/*****************************************************/
/* lex - a simple lexical analyzer for arithmetic
expressions */
int lex() {
	lexLen = 0;
	getNonBlank();
	switch (charClass) {
		/* Parse identifiers */
	case LETTER:
		addChar();
		getChar();
		while (charClass == LETTER || charClass == DIGIT) {
			addChar();
			prevClass = charClass;
			getChar();
		}
		nextToken = IDENT;
		break;
		/* Parse integer literals */
	case DIGIT:
		addChar();
		getChar();
		while (charClass == DIGIT) {
			addChar();
			getChar();
		}
		nextToken = INT_LIT;
		break;
		/* Parentheses and operators */
	case UNKNOWN:
		lookup(nextChar);
		getChar();
		if (prevToken == 24 && nextToken == 23) {
			addChar();
			getChar();
		}
		else if (prevToken == 23 && nextToken == 24) {
			addChar();
			getChar();
		}
		break;
		/* EOF */
	case EOF:
		nextToken = EOF;
		lexeme[0] = 'E';
		lexeme[1] = 'O';
		lexeme[2] = 'F';
		lexeme[3] = 0;
		break;
	} /* End of switch */
	if (prevToken == 24 && nextToken == 23)
	{
		printf("Comment detected! \n");
	}
	else if (prevToken == 23 && nextToken == 24)
	{
		printf("End of Comment detected! \n");
	}
	else if (prevClass == DIGIT && (charClass == LETTER || nextToken == SUB_OP))
	{
		printf("Floating point detected! \n");
	}
	printf("Next token is: %d, Next lexeme is %s\n",
		nextToken, lexeme);
	//prevToken = nextToken;
	return nextToken;
} /* End of function lex */
